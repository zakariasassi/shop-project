const express = require('express');
const {
  addRole,
  getRoles,
  deleteRole,
  getPermission,
  addPermission,
  assignPermissionToRole,
  deletePermission
} = require('../controllers/roleController.js');


const router = express.Router();

router.post('/', addRole);
router.get('/', getRoles);
router.delete('/:id', deleteRole);


router.post('/:role_id/permission', assignPermissionToRole);


router.post('/permission', addPermission);
router.get('/permission', getPermission);
router.delete('/permission/:id', deletePermission);


module.exports = router;
