// routes/cartRoutes.js
const express = require('express');
const CartController = require("../controllers/CartController.js");
const verify = require('../middleware/verifyToken.js');

const router = express.Router();

router.post('/', verify, CartController.addToCart);
router.get('/', verify , CartController.getCart);
router.put('/update-quantity', verify, CartController.updateQuantity);
router.delete('/remove-item/:id', verify, CartController.removeCartItem);


module.exports =  router;
