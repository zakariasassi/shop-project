const express = require('express');

// Import controller functions
const {
  getAllDoneOrders,
  getproductscount,
  getcustomerscount,
  gettotalofsales,
  getTopSellingProducts,
  SalesReport,
  OrdersReport,
  RecordVistsReport,
  ValueOfDropingCart,
  getUnitsSoldPerProduct,
  getMostVisitedProducts,
} = require('../controllers/ReportsController.js');




const router = express.Router();



router.get('/getalldoneorders' , getAllDoneOrders)
router.get('/getproductscount' , getproductscount)
router.get('/getcustomerscount' , getcustomerscount)
router.get('/gettotalofsales' , gettotalofsales)
router.get('/gettopsellingproducts' , getTopSellingProducts)
router.get('/salesreport' , SalesReport)
router.get('/ordersreport' ,  OrdersReport)
router.get('/RecordVistsReport' ,  RecordVistsReport)
router.get('/ValueOfDropingCart' , ValueOfDropingCart)
router.get('/getUnitsSoldPerProduct' , getUnitsSoldPerProduct)
router.get('/mostVisitedProducts' , getMostVisitedProducts)





module.exports = router; 