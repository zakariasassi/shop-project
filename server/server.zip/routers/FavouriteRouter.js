const express = require('express');
const FavouriteController = require('../controllers/FavouriteController.js');
const verify = require('../middleware/verifyToken.js');


const router = express.Router();


router.get('/', verify, FavouriteController.getAllUserFavourites);
router.post('/', verify, FavouriteController.addToList);
router.delete('/:id', verify, FavouriteController.removeFromList);


module.exports = router;
