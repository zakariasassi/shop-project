const express = require('express');
const WalletController = require('../controllers/WalletController.js');
const verify = require('../middleware/verifyToken.js');

const router = express.Router();

router.get('/balance', verify, WalletController.getBalance);
router.post('/charge', verify, WalletController.chargeWallet);


module.exports =  router;