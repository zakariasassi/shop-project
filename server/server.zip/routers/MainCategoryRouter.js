// routes/MainCategoryRoutes.js
const express = require('express');
const MainCategoryController = require('../controllers/MainCategoryController.js');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');


const router = express.Router();



const createFolderIfNotExists = (folder) => {
  if (!fs.existsSync(folder)) {
    fs.mkdirSync(folder, { recursive: true });
  }
};

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const folderPath = `public/uploads/images/mainCategorys/${uuidv4()}`;
    createFolderIfNotExists(folderPath);
    cb(null, folderPath);
  },
  filename: function (req, file, cb) {
    cb(null, `${Date.now()}${path.extname(file.originalname)}`);
  }
});

const upload = multer({ storage: storage });




router.post('/', upload.single('image') , MainCategoryController.create);
router.get('/', MainCategoryController.getAll);
router.get('/:id', MainCategoryController.getById);
router.put('/:id', MainCategoryController.update);
router.delete('/:id', MainCategoryController.delete);

module.exports = router;
