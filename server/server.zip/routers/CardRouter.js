const express = require('express');
const CardsController = require('../controllers/CardsController.js');
const verify = require('../middleware/verifyToken.js');

const router = express.Router();


// Route to create multiple cards
router.post('/', verify, CardsController.createCards);

// Route to get user's cards
router.get('/', verify, CardsController.getAll);

router.get('/:id', verify, CardsController.getUserCards);




module.exports = router;