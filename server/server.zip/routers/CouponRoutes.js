// routes/couponRoutes.js
const express = require('express');
const { createCoupon, getCoupons, updateCoupon, deleteCoupon, applyCoupon, deactivateCoupon } = require('../controllers/CouponController.js');


const router = express.Router();

router.post('/', createCoupon);
router.get('/', getCoupons);
router.put('/:id', updateCoupon);
router.delete('/:id', deleteCoupon);
router.post('/apply', applyCoupon);
router.post('/deactivateCoupon', deactivateCoupon);


module.exports =  router
